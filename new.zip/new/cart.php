<?php
session_start();
// session_destroy();
if ($_SERVER['REQUEST_METHOD']=='POST')
 {
    if (isset($_POST['add_to_cart'])) 
    {
        if (isset($_SESSION['cart1'])) {
            $myitems=array_column($_SESSION['cart1'], 'nameofproduct');
            if (in_array($_POST['nameofproduct'], $myitems)) {
                
                echo "<script>
                alert('Item is already added');
                window.location.href='http://localhost:8080/foodcart.php';

                </script>";
                // code...
            }
            else
            {
            $count=count($_SESSION['cart1']);
            $_SESSION['cart1'][$count]=array('nameofproduct' =>$_POST['nameofproduct'],'price' =>$_POST['price'],'quantity' =>1 );
             echo "<script>
                alert('Item is  added');
                window.location.href='http://localhost:8080/foodcart.php';

                </script>";
        
        }
    }
        else{
            $_SESSION['cart1'][0]=array('nameofproduct' =>$_POST['nameofproduct'],'price' =>$_POST['price'],'quantity' =>1 );
             echo "<script>
                alert('Item is added');
                window.location.href='http://localhost:8080/lunchoptions.php';

                </script>";
        
        }


        // code...
    }
            if (isset($_POST['remove_item']))
             {
                foreach ($_SESSION['cart1'] as $key => $value)
                 {
                    if($value['nameofproduct']==$_POST['nameofproduct']){
                    unset($_SESSION['cart1'][$key]);
                    $_SESSION['cart1']=array_values($_SESSION['cart1']);
                    echo "<script>
                    alert('Item removed');
                window.location.href='http://localhost:8080/foodcart.php';


                    </script>";
                }
            }
                // code...
            }



}
?>
<!-- //indexpage -->
<!-- put this cod ein the cart page -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<style type="text/css">
body{
    
    background-image: url("https://images5.alphacoders.com/547/547188.jpg");


}
    .container{
        margin-top: 30px;
    }
  /*  .col-lg-3{
        background-color: #e6e6e6;
        padding: 15px;
        text-align: center;

    }*/
    .sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: black;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a, .dropdown-btn {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 15px;
  color: #818181;
  display: block;
  border: none;
  background: none;
  width: 100%;
  text-align: left;
  cursor: pointer;
  outline: none;

}

.sidenav a:hover, .dropdown-btn:hover {
  color: white;
}


.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 17px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: white;
}

.active {
  color: white;
}

.dropdown-container-1{
  display: none;
  padding-left: 8px;
}


.fa-caret-down {
  float: right;
  padding-right: 8px;
}


.sidenav .closebtn {
 position: absolute;
        top: 20px;
        right: 20px;
        width: 40px;
        height: 40px;
        background-repeat: no-repeat;
        background-size: 10px;
        background-position: center;
        cursor: pointer;
        border-radius: 50%;
        z-index: 10;
        font-size: 20px;
        text-align: center;
        color: red;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
  margin-top: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

</style>
<body>
    <div class="container">
     <div id="main" >
 
  <span style="font-size:30px;cursor:pointer;color: white" onclick="openNav()">&#9776; </span>
</div>
</div>
    <div class="container">
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()" style="margin-left: 100px;">&times;</a>
   <div class="container">
       <?php if(isset($_SESSION['user_id'])){ ?>
    <b>
    <a href="#" style="font-size:23px;"><i class="fa fa-user-o" aria-hidden="true" style="font-size: 20px;"></i> <?php    echo $_SESSION[ 'username' ]; ?></a>
</b>
  <?php } else { ?>
    
  <?php } ?>
      
    </div>
   <a href="http://localhost:8080/index.php">Home</a>
    <a href="http://localhost:8080/vegetablepage.php">Vegetables</a>
    <a href="http://localhost:8080/fruitspage.php">Fruits</a>
     <a href="http://localhost:8080/bevarages.php#">Bevarages</a>
    <a href="http://localhost:8080/bakeryitems%20.php">Bakery</a>
    <a href="http://localhost:8080/pulses.php">Pulses</a>
     <a href="http://localhost:8080/dryfruits.php">Snacks</a>
  <a href="#">Contact</a> 
  <a href="#" style="margin-top: 20px;margin-left: 0px;"><i class="fa fa-sign-out" aria-hidden="true" style="color:red;font-size: 20px;" id="user1"></i> Signout</a>
 
 
  
</div>


</div>
    <div class="container" style="margin-left: 130px;margin-top: -30px;">
        <div class="row">
            <div class="col-lg-12 " >
                <h1 style="color:white;margin-left: 0px;margin-top: 0px;">My Orders <i class="fa fa-shopping-cart" aria-hidden="true" ></i></h1>                
            </div>
            <div class="col-lg-8">
            <table class="table">
  <thead>
    <hr>
    <tr style="color: white;">
      <th scope="col">Item</th>
      <th scope="col">Price</th>
      <th scope="col">Quantity</th>
      <th scope="col">Total</th>
    </tr>
  </thead>
  <tbody>
    <?php
    $total=0;
    if(isset($_SESSION['cart1'])){
    foreach ($_SESSION['cart1'] as $key => $value) {
        // print_r($value);

        // code...
        echo "
        <tr>
        <td style='color:white;font-size:17px;'>$value[nameofproduct]</td>
        <td style='color:white;font-size:17px;'>$value[price]<input type='hidden' class='iprice' value='$value[price]'></td>
        <td style='color:white;font-size:17px;outline:0px;'><input type='number'class='iquantity' onchange='subtotal()' value='$value[quantity]' min='1' max='10'></td>
        <td class='itotal' style='color:white;font-size:17px;'></td>
        <td>
        <form action='foodcart.php' method='POST'>
        <button class='btn btn-outline-primary btn-sm' name='remove_item'style='color:white;font-size:17px;'>remove</button>
        <input type='hidden' name='nameofproduct' value='$value[nameofproduct]'>
        </form>
        </td>

         </tr>
        ";
    }
}
    ?>
    
     
  </tbody>
</table> 
                
            </div>
                       
            
        </div>
        
    </div>
   
     <div style="margin-top:auto;margin-left: 140px;" class="container">
                <h3 style="color:white"> Grand Total: <span id="gtotal"></span></h3>


                <a href="https://rzp.io/l/YGeUiFB" class="btn btn-outline-danger btn-lg" style="font-size: 17px;margin-top: 12px;" target="_blank">Make Payment  <i class="fa fa-money" aria-hidden="true" style="font-size: 19px;"></i></a>

            </div>
<script type="text/javascript">
    var gt=0;
    var iprice=document.getElementsByClassName('iprice');
    var iquantity=document.getElementsByClassName('iquantity');
    var itotal=document.getElementsByClassName('itotal');
    var gtotal=document.getElementById('gtotal')

    function subtotal()
    {
        gt=0;
        for (i =0;i<iprice.length;i++)
         {

        itotal[i].innerText=(iprice[i].value)*(iquantity[i].value);
           gt=gt+(iprice[i].value)*(iquantity[i].value);

            
        }
        gtotal.innerText=gt;
    }


    subtotal();
</script>
<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
  document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
  document.body.style.backgroundColor = "white";
}



var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}
</script>
</body>
</html>
