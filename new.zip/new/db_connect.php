<?php
$sname= "localhost";
$unmae= "root";
$password = "";
$db_name = "webathon";
$con = mysqli_connect($sname, $unmae, $password, $db_name);
?>